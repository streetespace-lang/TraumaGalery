package com.traumagalery.app
import androidx.room.*
@Dao interface PatientDao {
    @Query("SELECT * FROM patients ORDER BY dateEntry DESC") suspend fun getAll(): List<Patient>
    @Insert suspend fun insert(patient: Patient): Long
    @Update suspend fun update(patient: Patient)
    @Delete suspend fun delete(patient: Patient)
}
