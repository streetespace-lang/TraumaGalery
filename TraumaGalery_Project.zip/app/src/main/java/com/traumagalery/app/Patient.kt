package com.traumagalery.app
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable
@Entity(tableName = "patients")
data class Patient(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    var name: String, var dateEntry: String, var surgeon: String, var diagnostic: String,
    var cpa: String, var material: String, var surgeryDateTime: String
): Serializable
