package com.traumagalery.app
import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
class AddEditPatientActivity: AppCompatActivity(){
    private lateinit var db: AppDatabase
    private var editing: Patient? = null
    override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); setContentView(R.layout.activity_add_edit_patient)
        db = AppDatabase.getInstance(this)
        val etName:EditText=findViewById(R.id.etName)
        val etDateEntry:EditText=findViewById(R.id.etDateEntry)
        val etSurgeon:EditText=findViewById(R.id.etSurgeon)
        val etDiag:EditText=findViewById(R.id.etDiagnosis)
        val etCpa:EditText=findViewById(R.id.etCpa)
        val etMaterial:EditText=findViewById(R.id.etMaterial)
        val etSurgery:EditText=findViewById(R.id.etSurgeryDateTime)
        val btnSave:Button=findViewById(R.id.btnSave)
        val p = intent.getSerializableExtra("patient") as? Patient
        if(p!=null){ editing=p; etName.setText(p.name); etDateEntry.setText(p.dateEntry); etSurgeon.setText(p.surgeon); etDiag.setText(p.diagnostic); etCpa.setText(p.cpa); etMaterial.setText(p.material); etSurgery.setText(p.surgeryDateTime) }
        etDateEntry.setOnClickListener { pickDate { d-> etDateEntry.setText(d) } }
        btnSave.setOnClickListener {
            val model=(editing?: Patient(0, etName.text.toString(), etDateEntry.text.toString(), etSurgeon.text.toString(), etDiag.text.toString(), etCpa.text.toString(), etMaterial.text.toString(), etSurgery.text.toString())).apply {
                name=etName.text.toString(); dateEntry=etDateEntry.text.toString(); surgeon=etSurgeon.text.toString(); diagnostic=etDiag.text.toString(); cpa=etCpa.text.toString(); material=etMaterial.text.toString(); surgeryDateTime=etSurgery.text.toString()
            }
            lifecycleScope.launch { withContext(Dispatchers.IO){ if(editing==null) db.patientDao().insert(model) else db.patientDao().update(model) }; setResult(RESULT_OK); finish() }
        }
    }
    private fun pickDate(onPicked:(String)->Unit){ val cal=Calendar.getInstance(); DatePickerDialog(this, {_,y,m,d-> cal.set(y,m,d); val fmt=SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()); onPicked(fmt.format(cal.time))}, cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show() }
}
