package com.traumagalery.app
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MainActivity: AppCompatActivity(){
    private lateinit var db: AppDatabase; private lateinit var adapter: PatientAdapter
    override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        db = AppDatabase.getInstance(this)
        val rv = findViewById<RecyclerView>(R.id.recyclerView); rv.layoutManager = LinearLayoutManager(this)
        adapter = PatientAdapter(listOf(), onEdit = { p ->
            val i = Intent(this, AddEditPatientActivity::class.java); i.putExtra("patient", p); startActivityForResult(i, 2)
        }, onDelete = { p -> lifecycleScope.launch { withContext(Dispatchers.IO){ db.patientDao().delete(p) }; load() } }, onToggleStatus = { _ -> })
        rv.adapter = adapter
        findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener { startActivityForResult(Intent(this, AddEditPatientActivity::class.java), 1) }
        load()
    }
    private fun load(){ lifecycleScope.launch { val list = withContext(Dispatchers.IO){ db.patientDao().getAll() }; adapter.update(list) } }
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?){ super.onActivityResult(requestCode, resultCode, data); if(resultCode==Activity.RESULT_OK) load() }
}
