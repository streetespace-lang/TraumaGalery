package com.traumagalery.app
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
class PatientAdapter(private var items: List<Patient>, private val onEdit:(Patient)->Unit, private val onDelete:(Patient)->Unit, private val onToggleStatus:(Patient)->Unit): RecyclerView.Adapter<PatientAdapter.VH>(){
    fun update(newItems: List<Patient>){ items = newItems; notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(LayoutInflater.from(parent.context).inflate(R.layout.patient_list_item, parent, false))
    override fun onBindViewHolder(h: VH, pos: Int){ val p=items[pos]; h.name.text=p.name; h.date.text="Date d’entrée: ${p.dateEntry}"; h.diag.text="Diagnostic: ${p.diagnostic}"; h.surgeon.text=p.surgeon; h.itemView.setOnClickListener{ onEdit(p) }; h.itemView.setOnLongClickListener{ onDelete(p); true } }
    override fun getItemCount(): Int = items.size
    class VH(v: View): RecyclerView.ViewHolder(v){ val name:TextView=v.findViewById(R.id.patientName); val date:TextView=v.findViewById(R.id.patientDate); val diag:TextView=v.findViewById(R.id.patientDiag); val surgeon:TextView=v.findViewById(R.id.patientSurgeon) }
}
